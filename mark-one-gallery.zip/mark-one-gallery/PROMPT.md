# Mark One Trade Show Gallery: Build Prompt

This is the prompt used to build the gallery in this zip. Give it to an AI coding assistant, together with product photos, to rebuild or extend the gallery.

## Original requests

1. "Want to build an interactive gallery for trade shows using Mark One products. I have 200 pics but uploading a few now to test. All photos should create an interactive sphere. Sidebar with search and filter options to filter the content of the sphere and scale of the objects. When a user clicks an object it scales up and displays detail info."
2. "Style like https://ed-goebel.ggoebel11.chatgpt.site. Have a screensaver mode where the objects turn into a clock."

## Full prompt

Build a standalone product gallery for Mark One Manufacturing to run on a trade show kiosk or large touchscreen. Use plain HTML, CSS and JavaScript with no frameworks or build step. It must run offline by opening `index.html`.

### Product sphere
- Place every product photo on a 3D sphere using a Fibonacci layout, so products are evenly spaced whether there are 5 or 200.
- The sphere spins slowly on its own. Visitors drag or swipe to spin it (with inertia), and scroll or pinch to zoom.
- Products always face the viewer. Products on the far side are smaller and dimmer.
- A faint sphere of dots behind the products shows the shape even when only a few products are visible.
- Group products by category, so each category forms a band on the sphere. Products marked "featured" come first.
- Product photos are transparent PNG cut-outs, so they float on the sphere without a card behind them. Photos with a background show as rounded cards instead.
- If the whole catalog is very small (for example, 5 test photos), repeat the products to fill the sphere. This stops once there are enough real products.
- It must stay at 60 fps with 200 products.

### Sidebar
- Search across name, category, material, process, finish, industries, description, tags and specs.
- Filter buttons for Category, Material, Process, Finish and Industry. Each button shows how many products match. Choices within a group widen the results, and choices across groups narrow them.
- A results count and a Reset link.
- Sliders for object size, sphere size and spin speed.
- The sidebar folds away. On phones it starts closed and opens over the sphere.

### Product detail
- When a visitor taps a product, the sphere turns it to the front and the image grows smoothly from its spot into a large view.
- The detail view shows the category, the product name, a description, material, process, finish, industries, specs and tags.
- Previous and Next buttons (and the ← → keys) step through the filtered products. Esc, the close button or a tap outside closes it.

### Clock screensaver
- After 60 seconds with nobody touching the screen, or when a visitor taps the clock button, products fly off the sphere and line up into a 5×7 dot-matrix clock (H:MM or HH:MM) with a blinking colon.
- Show the date and "Touch to explore our work." under the clock.
- The rest of the sphere keeps turning faintly in the background.
- Each minute, only the dots that change get new products.
- Any touch or key sends the products back to the sphere. That touch must not also spin the sphere or open a product.
- Starting the screensaver also closes the detail view and clears search and filters, so each visitor starts fresh.
- Settings in `config.js`: idle time for the screensaver, idle time for the reset, 12- or 24-hour clock, and spin speed.

### Visual style (matching the Ed Goebel / Mark One site)
- Near-black background with a slight green tint (`#121411`) and a faint dot grid.
- Off-white text (`#f1efe7`), muted grey-green (`#9a9d91`) for secondary text, and a lime accent (`#d6f250`).
- Headlines in Inter Tight: heavy, very tight letter spacing, ending in a lime period ("MARK ONE.", "Threaded Eye Bolt.").
- Body text in DM Sans. Labels are small uppercase with wide letter spacing.
- Filter chips are outline pills. Selected chips fill off-white with dark text, like the site's Work/About/Contact nav.
- Round outline icon buttons with lime icons. Links in lime with an underline.
- Thin divider lines between sections.

### Photo and data pipeline
- `photos/` holds the original photos. `tools/build_catalog.py` (uses Pillow) does the following:
  - Trims transparent cut-outs to the product outline.
  - Writes WebP copies to `images/` (1600 px, for the detail view) and `thumbs/` (480 px, for the sphere).
  - Adds a row to `products.csv` for each new photo, without overwriting rows that were already edited.
  - Generates `products.js`.
- `products.csv` columns: `id, name, category, material, process, finish, industries, description, specs, tags, featured`.
  - `industries` and `tags` separate values with `|`.
  - `specs` is written as `Label: value; Label: value`.
  - `featured` is `yes` to show the product first in its category.

## Notes
- The 5 test products have names, materials, processes and descriptions guessed from their photos. Replace them with real data in `products.csv`.
- The fonts load from Google Fonts. For an offline booth, bundle the font files locally.
